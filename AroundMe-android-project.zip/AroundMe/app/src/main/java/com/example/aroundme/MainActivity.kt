package com.example.aroundme

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val categories = listOf(
        "🛒 Stores" to "stores",
        "🍽️ Restaurants" to "restaurants",
        "☕ Cafés" to "cafes",
        "🛍️ Supermarkets" to "supermarket",
        "💊 Pharmacies" to "pharmacy",
        "⛽ Gas stations" to "gas station",
        "🏧 ATMs" to "atm",
        "🏨 Hotels" to "hotels",
        "🏥 Hospitals" to "hospital",
        "🌳 Parks" to "parks",
        "🎬 Cinemas" to "cinema",
        "🅿️ Parking" to "parking"
    )

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    // geo:0,0?q=... makes Google Maps search around the phone's current location.
    private fun openMaps(query: String) {
        val q = Uri.encode(query)
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q")))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/$q+near+me"))
                )
            } catch (e2: Exception) {
                Toast.makeText(this, "No maps app or browser found", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val blue = Color.parseColor("#2563EB")
        val dark = Color.parseColor("#14161C")
        val grey = Color.parseColor("#667085")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }

        root.addView(TextView(this).apply {
            text = "Around Me"
            textSize = 28f
            setTextColor(dark)
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Tap the button to find stores and places near you."
            textSize = 15f
            setTextColor(grey)
            setPadding(0, dp(4), 0, dp(20))
        })

        val results = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }

        val go = Button(this).apply {
            text = "📍  Around me"
            textSize = 20f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(blue, 18)
            setPadding(dp(16), dp(22), dp(16), dp(22))
            setOnClickListener { results.visibility = View.VISIBLE }
        }
        root.addView(go)

        results.addView(TextView(this).apply {
            text = "NEARBY"
            textSize = 13f
            setTextColor(grey)
            setPadding(dp(4), dp(22), 0, dp(6))
        })

        categories.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(5), 0, dp(5))
            }
            pair.forEach { (label, query) ->
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(dp(5), 0, dp(5), 0)
                row.addView(Button(this).apply {
                    text = label
                    isAllCaps = false
                    textSize = 16f
                    gravity = Gravity.START or Gravity.CENTER_VERTICAL
                    setTextColor(dark)
                    background = rounded(Color.WHITE, 14, Color.parseColor("#E4E7EC"))
                    setPadding(dp(14), dp(16), dp(14), dp(16))
                    setOnClickListener { openMaps(query) }
                }, lp)
            }
            results.addView(row)
        }

        results.addView(TextView(this).apply {
            text = "SEARCH FOR SOMETHING ELSE"
            textSize = 13f
            setTextColor(grey)
            setPadding(dp(4), dp(22), 0, dp(6))
        })

        val input = EditText(this).apply {
            hint = "e.g. pizza, hardware store"
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setSingleLine(true)
        }
        val search = Button(this).apply {
            text = "Search"
            isAllCaps = false
            setOnClickListener {
                val v = input.text.toString().trim()
                if (v.isNotEmpty()) openMaps(v)
            }
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { search.performClick(); true } else false
        }
        results.addView(input)
        results.addView(search)

        root.addView(results)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#F6F7FB"))
            addView(root)
        })
    }
}
